package c22.emitter;

import org.jcsp.lang.*






interface ManipulateInterface extends Serializable {
	
	abstract manipulate(id)
	abstract display(now)
}
