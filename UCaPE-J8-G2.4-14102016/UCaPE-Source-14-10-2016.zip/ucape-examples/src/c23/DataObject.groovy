package c23








class DataObject implements Serializable {
	def value
}
