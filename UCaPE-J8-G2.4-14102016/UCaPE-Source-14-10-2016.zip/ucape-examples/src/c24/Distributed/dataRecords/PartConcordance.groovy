package c24.Distributed.dataRecords

class PartConcordance implements Serializable{
  def seqVal
  def entryMap
}
